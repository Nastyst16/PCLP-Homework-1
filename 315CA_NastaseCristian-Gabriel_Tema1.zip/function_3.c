// Nastase Cristian-Gabriel 315CA
#include <stdio.h>

//functii penru problema "gigel_and_the_checkboard"

int absolut(long long x)
{
	if (x < 0)
		return -x;
	else
		return x;
}
