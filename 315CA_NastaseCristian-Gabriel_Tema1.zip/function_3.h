// Nastase Cristian-Gabriel 315CA
#pragma once

#include <stdio.h>

//functii penru problema "gigel_and_the_checkboard"

int absolut(long long x);
