// Nastase Cristian-Gabriel 315CA
#pragma once

#include <stdio.h>

//functii pentru problema "simple_queries"

void numarul_de_aparitii(int vf[]);
void topul_literelor(int vf[], int vf2[]);
void eliminare_litera(int vf[], int *f);
void alerta(int *f, int *u_a, int vf[]);
int cmmdc(int a, int b);
