// Nastase Cristian-Gabriel 315CA
#pragma once

#include <stdio.h>

//functii pentru problema "infinite_product"

long long baza8_baza10(long long x);
